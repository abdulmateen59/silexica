#! /bin/bash

# do random stuff