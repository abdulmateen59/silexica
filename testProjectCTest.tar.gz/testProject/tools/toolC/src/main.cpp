#include <iostream>
#include <libC/Geeks.h>

int main() 
{
    Geeks obj1; 
  
    obj1.name = "CrazyDude"; 
    obj1.printname(); 

    return 0;
}
