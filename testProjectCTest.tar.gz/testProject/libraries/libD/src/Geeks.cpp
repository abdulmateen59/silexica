#include <libException/Geeks.h>

#include <iostream>

void Geeks::printname() { 
  std::cout << "Geekname is: " << name << std::endl; 
} 