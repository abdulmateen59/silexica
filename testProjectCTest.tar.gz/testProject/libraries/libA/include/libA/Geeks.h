#include <string>

class Geeks 
{ 
    public: 
  
    std::string name; 
  
    void printname();
}; 