#include "testHelper.h"
#include <iostream>

int main() 
{
    std::cout << NUMBER << std::endl;
    return 0;
}