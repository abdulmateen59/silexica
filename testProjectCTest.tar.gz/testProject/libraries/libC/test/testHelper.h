#ifndef TEST_HELPER_H
#define TEST_HELPER_H

#define NUMBER 10

#endif